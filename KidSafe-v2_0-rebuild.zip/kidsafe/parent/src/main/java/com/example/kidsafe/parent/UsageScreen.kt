package com.example.kidsafe.parent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.example.kidsafe.core.Fmt
import com.example.kidsafe.core.ScreenTimeGoal
import com.example.kidsafe.core.SettingsDoc
import com.example.kidsafe.ui.Banner
import com.example.kidsafe.ui.ChoiceChips
import com.example.kidsafe.ui.EmptyState
import com.example.kidsafe.ui.KsCard
import com.example.kidsafe.ui.KsScreen
import com.example.kidsafe.ui.Loading
import com.example.kidsafe.ui.Muted
import com.example.kidsafe.ui.SectionTitle
import com.example.kidsafe.ui.Tone
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions

data class AppRow(val name: String, val ms: Long)
data class DayUsage(val date: String, val totalMs: Long, val apps: List<AppRow>)

@Suppress("UNCHECKED_CAST")
private fun DocumentSnapshot.toDay(): DayUsage {
    val list = (get("apps") as? List<Map<String, Any?>>).orEmpty()
    return DayUsage(
        date = getString("date") ?: id,
        totalMs = getLong("totalMs") ?: 0L,
        apps = list.map {
            AppRow(
                name = (it["name"] as? String) ?: (it["pkg"] as? String) ?: "?",
                ms = (it["ms"] as? Number)?.toLong() ?: 0L,
            )
        },
    )
}

/** App usage for the last 7 days, plus the daily screen-time goal. */
@Composable
fun UsageScreen(child: ChildInfo, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var days by remember { mutableStateOf<List<DayUsage>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var goalMinutes by remember { mutableStateOf(0) }
    val today = remember { todayKey() }

    val goalRef = remember(child.id) {
        db.collection(Col.CHILDREN).document(child.id)
            .collection(Col.SETTINGS).document(SettingsDoc.SCREEN_TIME)
    }

    BackHandler(onBack = onBack)

    DisposableEffect(child.id) {
        val registration = db.collection(Col.CHILDREN).document(child.id).collection(Col.USAGE)
            .orderBy("date", Query.Direction.DESCENDING)
            .limit(7)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    error = e.localizedMessage
                    return@addSnapshotListener
                }
                days = snap?.documents?.map { it.toDay() }.orEmpty()
                loaded = true
            }
        val goalRegistration = goalRef.addSnapshotListener { snap, _ ->
            goalMinutes = (snap?.getLong("minutes") ?: 0L).toInt()
        }
        onDispose {
            registration.remove()
            goalRegistration.remove()
        }
    }

    val day = days.getOrNull(selected)

    KsScreen(title = "${child.name} · App usage", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp),
        ) {
            error?.let { item { Banner(it, tone = Tone.Danger) } }

            // ---- Daily goal ----
            item {
                KsCard {
                    Text("⏳ Daily screen-time goal", style = MaterialTheme.typography.titleMedium)
                    Muted(
                        "${child.name} sees the goal and gets a gentle reminder when it's reached. " +
                            "You get an alert too. Nothing is blocked.",
                    )
                    ChoiceChips(
                        options = ScreenTimeGoal.PRESETS,
                        selected = goalMinutes,
                        label = { if (it == 0) "Off" else Fmt.goal(it) },
                        onSelect = { m ->
                            goalMinutes = m
                            goalRef.set(mapOf("minutes" to m), SetOptions.merge())
                        },
                    )
                }
            }

            if (days.isEmpty()) {
                item {
                    if (loaded) {
                        EmptyState(
                            "📊",
                            "No report yet",
                            "It appears after the child turns on usage reporting on their phone " +
                                "(first report within a few minutes, then every ~30 min).",
                        )
                    } else {
                        Loading()
                    }
                }
            } else {
                item {
                    ChoiceChips(
                        options = days.indices.toList(),
                        selected = selected,
                        label = { i -> if (days[i].date == today) "Today" else days[i].date.takeLast(5) },
                        onSelect = { selected = it },
                    )
                }
                if (day != null) {
                    item {
                        KsCard {
                            Text(
                                "Total app time: ${Fmt.duration(day.totalMs)}",
                                style = MaterialTheme.typography.titleMedium,
                            )
                            if (day.date == today && goalMinutes > 0) {
                                LinearProgressIndicator(
                                    progress = { ScreenTimeGoal.progress(day.totalMs, goalMinutes) },
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Muted(
                                    if (ScreenTimeGoal.isExceeded(day.totalMs, goalMinutes)) {
                                        "Goal of ${Fmt.goal(goalMinutes)} reached."
                                    } else {
                                        "Goal: ${Fmt.goal(goalMinutes)}"
                                    },
                                )
                            }
                        }
                    }
                    item { SectionTitle("Apps") }
                    val max = (day.apps.maxOfOrNull { it.ms } ?: 1L).coerceAtLeast(1L)
                    items(day.apps) { a ->
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(a.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(Fmt.duration(a.ms))
                            }
                            LinearProgressIndicator(
                                progress = { a.ms.toFloat() / max },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                }
            }
        }
    }
}
