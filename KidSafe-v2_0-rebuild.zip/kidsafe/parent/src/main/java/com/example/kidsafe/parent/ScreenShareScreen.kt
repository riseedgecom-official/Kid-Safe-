package com.example.kidsafe.parent

import android.graphics.BitmapFactory
import android.text.format.DateUtils
import android.util.Base64
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import com.example.kidsafe.core.Col
import com.example.kidsafe.ui.Banner
import com.example.kidsafe.ui.EmptyState
import com.example.kidsafe.ui.KsCard
import com.example.kidsafe.ui.KsScreen
import com.example.kidsafe.ui.Muted
import com.example.kidsafe.ui.Tone
import com.google.firebase.firestore.FirebaseFirestore

/** Watch-only view of the child's shared screen. Only the child can start or stop sharing. */
@Composable
fun ScreenShareScreen(child: ChildInfo, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var active by remember { mutableStateOf(false) }
    var frameBytes by remember { mutableStateOf<ByteArray?>(null) }
    var updatedAt by remember { mutableStateOf<Long?>(null) }
    var endsAt by remember { mutableStateOf<Long?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    DisposableEffect(child.id) {
        val registration = db.collection(Col.CHILDREN).document(child.id)
            .collection(Col.SCREENSHARE).document("live")
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    error = e.localizedMessage
                    return@addSnapshotListener
                }
                active = snap?.getBoolean("active") == true
                val b64 = snap?.getString("frame")
                frameBytes = if (active && !b64.isNullOrEmpty()) {
                    runCatching { Base64.decode(b64, Base64.NO_WRAP) }.getOrNull()
                } else {
                    null
                }
                updatedAt = snap?.getTimestamp("ts")?.toDate()?.time
                endsAt = snap?.getTimestamp("endsAt")?.toDate()?.time
            }
        onDispose { registration.remove() }
    }

    KsScreen(title = "${child.name} · Screen share", onBack = onBack) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            error?.let { Banner(it, tone = Tone.Danger) }
            Muted(
                "Only ${child.name} can start or stop this from their phone. There is no button " +
                    "here to turn it on.",
            )

            val bytes = frameBytes
            if (active && bytes != null) {
                val bmp = remember(bytes) {
                    runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }.getOrNull()
                }
                if (bmp != null) {
                    KsCard(padding = 0.dp) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "${child.name}'s screen",
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.FillWidth,
                        )
                    }
                }
                val freshness = updatedAt?.let {
                    DateUtils.getRelativeTimeSpanString(
                        it, System.currentTimeMillis(), DateUtils.SECOND_IN_MILLIS,
                    ).toString()
                } ?: "just now"
                Muted("Updated $freshness · refreshes every couple of seconds")
                endsAt?.let {
                    val remain = ((it - System.currentTimeMillis()) / 60_000L).coerceAtLeast(0)
                    Text(
                        "Ends in about $remain min, or sooner if ${child.name} stops it.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            } else {
                EmptyState(
                    "🖥️",
                    "Not sharing right now",
                    "If ${child.name} needs to show you something, ask them to open KidSafe and tap " +
                        "“Share my screen”.",
                )
            }
        }
    }
}
