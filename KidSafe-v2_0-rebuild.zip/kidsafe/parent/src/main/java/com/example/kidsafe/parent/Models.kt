package com.example.kidsafe.parent

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.kidsafe.core.EventType
import com.example.kidsafe.ui.Tone
import com.example.kidsafe.ui.agoText
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Everything the parent app shows about one linked child (one live Firestore document). */
data class ChildInfo(
    val id: String,
    val name: String,
    val lat: Double?,
    val lng: Double?,
    val battery: Int?,
    val locTime: Long?,
    val eventType: String?,
    val eventTime: Long?,
    val eventLat: Double?,
    val eventLng: Double?,
    val eventPlace: String?,
    val eventMinutes: Int?,
    // Added in the v2 rebuild. All optional, so records written by older child apps still load.
    val accuracyM: Int? = null,
    val moving: Boolean = false,
    val lastSeen: Long? = null,
    val eventBattery: Int? = null,
    val usageTodayMs: Long? = null,
    val usageDate: String? = null,
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toChild(): ChildInfo {
    val loc = get("lastLocation") as? Map<String, Any?>
    val ev = get("lastEvent") as? Map<String, Any?>
    val usage = get("usageToday") as? Map<String, Any?>
    return ChildInfo(
        id = id,
        name = getString("name") ?: "Child",
        lat = (loc?.get("lat") as? Number)?.toDouble(),
        lng = (loc?.get("lng") as? Number)?.toDouble(),
        battery = (loc?.get("battery") as? Number)?.toInt(),
        locTime = (loc?.get("ts") as? Timestamp)?.toDate()?.time,
        eventType = ev?.get("type") as? String,
        eventTime = (ev?.get("ts") as? Timestamp)?.toDate()?.time,
        eventLat = (ev?.get("lat") as? Number)?.toDouble(),
        eventLng = (ev?.get("lng") as? Number)?.toDouble(),
        eventPlace = ev?.get("place") as? String,
        eventMinutes = (ev?.get("minutes") as? Number)?.toInt(),
        accuracyM = (loc?.get("accuracy") as? Number)?.toInt(),
        moving = (loc?.get("mode") as? String) == "moving",
        lastSeen = getTimestamp("lastSeen")?.toDate()?.time,
        eventBattery = (ev?.get("battery") as? Number)?.toInt(),
        usageTodayMs = (usage?.get("totalMs") as? Number)?.toLong(),
        usageDate = usage?.get("date") as? String,
    )
}

/** "2026-11-07": the same day key the child app uses for its usage reports. */
fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

/** The last time the child's phone gave any sign of life (location or heartbeat). */
fun ChildInfo.lastActive(): Long? = listOfNotNull(lastSeen, locTime).maxOrNull()

/** The child's phone sends a heartbeat every ~10 minutes; 30 minutes without one is worth a warning. */
const val QUIET_AFTER_MS = 30 * 60_000L

fun ChildInfo.isQuiet(now: Long = System.currentTimeMillis()): Boolean {
    val t = lastActive() ?: return false
    return now - t > QUIET_AFTER_MS
}

/** Today's screen time in ms, or null if the child's phone hasn't reported any for today. */
fun ChildInfo.usageTodayOrNull(): Long? = if (usageDate == todayKey()) usageTodayMs else null

/** One line describing the child's latest event, with a colour for how urgent it is. */
data class EventLine(val text: String, val tone: Tone)

fun ChildInfo.eventLine(): EventLine? {
    val whenText = agoText(eventTime)
    return when (eventType) {
        EventType.SOS -> EventLine("🚨 SOS $whenText", Tone.Danger)
        EventType.PERMISSION_GRANTED -> EventLine("✅ Child allowed location sharing $whenText", Tone.Success)
        EventType.GEOFENCE_ENTER -> EventLine("📍 Arrived at ${eventPlace ?: "a saved place"} $whenText", Tone.Info)
        EventType.GEOFENCE_EXIT -> EventLine("🚶 Left ${eventPlace ?: "a saved place"} $whenText", Tone.Info)
        EventType.WEB_BLOCKED -> EventLine("🚫 Blocked site: ${eventPlace ?: "?"} $whenText", Tone.Neutral)
        EventType.FILTER_OFF -> EventLine("⚠️ Web protection was turned off $whenText", Tone.Danger)
        EventType.USAGE_ACCESS_GRANTED -> EventLine("✅ Child allowed app usage reporting $whenText", Tone.Success)
        EventType.NEED_TALK -> EventLine("💬 $name wants to talk $whenText", Tone.Danger)
        EventType.SCREEN_SHARE_START ->
            EventLine("🖥️ Started sharing screen (${eventMinutes ?: "?"} min) $whenText", Tone.Info)
        EventType.SCREEN_SHARE_END -> EventLine("🖥️ Screen sharing ended $whenText", Tone.Neutral)
        EventType.CHAT_MESSAGE -> EventLine("💬 $name: “${eventPlace ?: ""}” $whenText", Tone.Info)
        EventType.BATTERY_LOW ->
            EventLine("🔋 Battery low${eventBattery?.let { " ($it%)" }.orEmpty()} $whenText", Tone.Warning)
        EventType.CHECK_IN -> EventLine("✅ $name checked in — safe $whenText", Tone.Success)
        EventType.SCREEN_LIMIT -> EventLine("⏳ Reached today's screen-time goal $whenText", Tone.Warning)
        else -> null
    }
}

/** Opens the phone's map app on a point. */
fun openMap(ctx: Context, lat: Double, lng: Double, label: String) {
    val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(label)})")
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
}
