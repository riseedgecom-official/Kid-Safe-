package com.example.kidsafe.parent

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.kidsafe.ui.Banner
import com.example.kidsafe.ui.HeroCard
import com.example.kidsafe.ui.KsTheme
import com.example.kidsafe.ui.Muted
import com.example.kidsafe.ui.OutlineButton
import com.example.kidsafe.ui.PrimaryButton
import com.example.kidsafe.ui.Tone
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KsTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) { ParentApp() }
                }
            }
        }
    }
}

@Composable
fun ParentApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val ctx = LocalContext.current
    var user by remember { mutableStateOf(auth.currentUser) }
    val u = user
    if (u == null) {
        AuthScreen { user = auth.currentUser }
    } else {
        ParentHome(
            uid = u.uid,
            email = u.email,
            onSignOut = {
                ctx.stopService(Intent(ctx, AlertService::class.java))
                auth.signOut()
                user = null
            },
        )
    }
}

@Composable
private fun AuthScreen(onSignedIn: () -> Unit) {
    val auth = remember { FirebaseAuth.getInstance() }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }

    fun submit(task: () -> Task<AuthResult>) {
        busy = true
        error = null
        info = null
        task().addOnCompleteListener {
            busy = false
            if (it.isSuccessful) onSignedIn() else error = it.exception?.localizedMessage ?: "Failed."
        }
    }

    fun resetPassword() {
        busy = true
        error = null
        info = null
        auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener {
            busy = false
            if (it.isSuccessful) {
                info = "If ${email.trim()} has an account, a password reset email is on its way."
            } else {
                error = it.exception?.localizedMessage ?: "Could not send the email."
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
    ) {
        HeroCard {
            Text("🛡️ KidSafe", style = MaterialTheme.typography.headlineLarge)
            Text("Family safety, made simple", style = MaterialTheme.typography.titleMedium)
            Text("PARENT APP", style = MaterialTheme.typography.labelMedium)
        }
        Text("Parent sign in", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
        )
        PrimaryButton(
            text = "Sign in",
            enabled = !busy && email.isNotBlank() && password.length >= 6,
            modifier = Modifier.fillMaxWidth(),
            onClick = { submit { auth.signInWithEmailAndPassword(email.trim(), password) } },
        )
        OutlineButton(
            text = "Create account",
            enabled = !busy && email.isNotBlank() && password.length >= 6,
            modifier = Modifier.fillMaxWidth(),
            onClick = { submit { auth.createUserWithEmailAndPassword(email.trim(), password) } },
        )
        TextButton(
            enabled = !busy && email.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
            onClick = { resetPassword() },
        ) { Text("Forgot password?") }
        Muted("Forgot it? Type your email above, then tap “Forgot password?”.")
        error?.let { Banner(it, tone = Tone.Danger) }
        info?.let { Banner(it, tone = Tone.Success) }
    }
}
