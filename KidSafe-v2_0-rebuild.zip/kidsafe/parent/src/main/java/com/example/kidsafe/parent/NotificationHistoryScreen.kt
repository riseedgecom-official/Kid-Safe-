package com.example.kidsafe.parent

import android.text.format.DateUtils
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.kidsafe.ui.ChoiceChips
import com.example.kidsafe.ui.EmptyState
import com.example.kidsafe.ui.KsCard
import com.example.kidsafe.ui.Loading
import com.example.kidsafe.ui.Muted
import com.example.kidsafe.ui.SectionTitle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun groupLabel(ms: Long, dateFormat: SimpleDateFormat): String = when {
    DateUtils.isToday(ms) -> "Today"
    DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    else -> dateFormat.format(Date(ms))
}

private fun relativeTime(ms: Long): String =
    DateUtils.getRelativeTimeSpanString(ms, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()

/** The "Alerts" tab: every alert this phone received since the app was installed, newest first. */
@Composable
fun AlertsTab(uid: String, padding: PaddingValues) {
    val appContext = LocalContext.current.applicationContext
    var all by remember { mutableStateOf<List<SavedNotification>>(emptyList()) }
    var total by remember { mutableStateOf(0) }
    var loaded by remember { mutableStateOf(false) }
    var onlyChild by remember { mutableStateOf<String?>(null) }

    // Reading this makes the list refresh when a new alert arrives while it is open.
    val changes = NotificationStore.version

    LaunchedEffect(uid, changes) {
        NotificationStore.load(appContext, uid) { list, count ->
            all = list
            total = count
            loaded = true
        }
    }

    // One chip per child (newest name wins, because the list is newest first).
    val children = remember(all) { all.distinctBy { it.childId }.map { it.childId to it.childName } }
    val shown = remember(all, onlyChild) {
        val wanted = onlyChild
        if (wanted == null) all else all.filter { it.childId == wanted }
    }

    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    val dateFormat = remember { SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()) }
    val dayKeyFormat = remember { SimpleDateFormat("yyyyMMdd", Locale.US) }

    LazyColumn(
        modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp),
    ) {
        item {
            Muted("Every alert this phone received since you installed the app, newest first.")
        }

        if (children.size > 1) {
            item {
                // Option 0 = everyone, then one chip per child.
                val options = listOf<String?>(null) + children.map { it.first }
                ChoiceChips(
                    options = options,
                    selected = onlyChild,
                    label = { id -> if (id == null) "All" else children.firstOrNull { it.first == id }?.second ?: id },
                    onSelect = { onlyChild = it },
                )
            }
        }

        if (!loaded) {
            item { Loading() }
        } else if (shown.isEmpty()) {
            item {
                EmptyState(
                    "🔔",
                    "No notifications yet",
                    "SOS, arrived, left, battery and blocked-site alerts will be saved here.",
                )
            }
        } else {
            if (total > all.size) {
                item { Muted("Showing the latest ${all.size} of $total saved alerts.") }
            }
            itemsIndexed(shown, key = { _, n -> n.id }) { index, n ->
                val newDay = index == 0 ||
                    dayKeyFormat.format(Date(shown[index - 1].time)) != dayKeyFormat.format(Date(n.time))
                if (newDay) SectionTitle(groupLabel(n.time, dateFormat))
                KsCard(Modifier.fillMaxWidth()) {
                    Text(n.title, style = MaterialTheme.typography.titleMedium)
                    Text(n.text, style = MaterialTheme.typography.bodyMedium)
                    Muted("${timeFormat.format(Date(n.time))} · ${relativeTime(n.time)}")
                }
            }
        }
    }
}
