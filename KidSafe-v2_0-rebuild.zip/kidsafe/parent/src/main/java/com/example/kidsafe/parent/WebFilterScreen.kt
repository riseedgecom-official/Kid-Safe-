package com.example.kidsafe.parent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.example.kidsafe.core.Input
import com.example.kidsafe.core.SettingsDoc
import com.example.kidsafe.ui.Banner
import com.example.kidsafe.ui.KsCard
import com.example.kidsafe.ui.KsScreen
import com.example.kidsafe.ui.Muted
import com.example.kidsafe.ui.PrimaryButton
import com.example.kidsafe.ui.SectionTitle
import com.example.kidsafe.ui.SwitchRow
import com.example.kidsafe.ui.Tone
import com.example.kidsafe.ui.agoText
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions

private data class Attempt(val domain: String, val time: Long?, val source: String)

/** Turn the family-safe filter on/off, add your own blocked sites, and see blocked attempts. */
@Suppress("UNCHECKED_CAST")
@Composable
fun WebFilterScreen(child: ChildInfo, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    val childRef = remember(child.id) { db.collection(Col.CHILDREN).document(child.id) }
    val settingsRef = remember(child.id) { childRef.collection(Col.SETTINGS).document(SettingsDoc.WEB_FILTER) }

    var enabled by remember { mutableStateOf(false) }
    var domains by remember { mutableStateOf<List<String>>(emptyList()) }
    var active by remember { mutableStateOf(false) }
    var privateDns by remember { mutableStateOf("") }
    var attempts by remember { mutableStateOf<List<Attempt>>(emptyList()) }
    var newDomain by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    DisposableEffect(child.id) {
        val r1 = settingsRef.addSnapshotListener { snap, e ->
            if (e != null) {
                error = e.localizedMessage
                return@addSnapshotListener
            }
            enabled = snap?.getBoolean("enabled") == true
            domains = (snap?.get("domains") as? List<*>)?.filterIsInstance<String>().orEmpty().sorted()
        }
        val r2 = childRef.addSnapshotListener { snap, _ ->
            val wf = snap?.get("webFilter") as? Map<String, Any?>
            active = wf?.get("active") == true
            privateDns = (wf?.get("privateDns") as? String).orEmpty()
        }
        val r3 = childRef.collection(Col.BLOCKED)
            .orderBy("ts", Query.Direction.DESCENDING)
            .limit(30)
            .addSnapshotListener { snap, _ ->
                attempts = snap?.documents?.mapNotNull { d ->
                    Attempt(
                        domain = d.getString("domain") ?: return@mapNotNull null,
                        time = d.getTimestamp("ts")?.toDate()?.time,
                        source = d.getString("source").orEmpty(),
                    )
                }.orEmpty()
            }
        onDispose {
            r1.remove()
            r2.remove()
            r3.remove()
        }
    }

    KsScreen(title = "${child.name} · Web filter", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp),
        ) {
            error?.let { item { Banner(it, tone = Tone.Danger) } }

            item {
                KsCard {
                    SwitchRow(
                        title = "Block adult & unsafe websites",
                        subtitle = "Uses a family-safe DNS on ${child.name}'s phone. " +
                            "Only website names are checked, nothing else is read.",
                        checked = enabled,
                        onChecked = { settingsRef.set(mapOf("enabled" to it), SetOptions.merge()) },
                    )
                }
            }

            item {
                when {
                    !enabled -> Banner("Filter is off.", tone = Tone.Neutral)
                    active -> Banner("✅ Active on ${child.name}'s phone.", tone = Tone.Success)
                    else -> Banner(
                        "⏳ Waiting. ${child.name} must open the KidSafe app and tap " +
                            "“Turn on web protection” (one time).",
                        tone = Tone.Warning,
                    )
                }
            }

            if (enabled && privateDns == "hostname") {
                item {
                    Banner(
                        "⚠️ ${child.name}'s phone uses a custom “Private DNS”. That can bypass this filter. " +
                            "Set it to Off or Automatic in Settings → Network → Private DNS.",
                        tone = Tone.Danger,
                    )
                }
            }

            item { SectionTitle("Also block these sites") }
            item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedTextField(
                        value = newDomain,
                        onValueChange = { newDomain = it },
                        label = { Text("example.com") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    PrimaryButton(text = "Add", onClick = {
                        val d = Input.normalizeDomain(newDomain)
                        if (d == null) {
                            error = "Enter a site like example.com"
                        } else {
                            settingsRef.set(
                                mapOf("domains" to FieldValue.arrayUnion(d)),
                                SetOptions.merge(),
                            )
                            newDomain = ""
                            error = null
                        }
                    })
                }
            }
            if (domains.isEmpty()) {
                item { Muted("No extra sites. (Works only while the filter above is on.)") }
            }
            items(domains) { d ->
                KsCard(padding = 10.dp) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(d, Modifier.weight(1f))
                        TextButton(onClick = {
                            settingsRef.set(
                                mapOf("domains" to FieldValue.arrayRemove(d)),
                                SetOptions.merge(),
                            )
                        }) { Text("Remove") }
                    }
                }
            }

            item { SectionTitle("Recent blocked attempts") }
            if (attempts.isEmpty()) {
                item { Muted("None yet.") }
            }
            items(attempts) { a ->
                val whenText = a.time?.let { agoText(it) } ?: "just now"
                val why = if (a.source == "parent_list") "your list" else "unsafe site"
                KsCard(padding = 12.dp) {
                    Text("🚫 ${a.domain}", style = MaterialTheme.typography.titleSmall)
                    Muted("$whenText · blocked by $why")
                }
            }
        }
    }
}
