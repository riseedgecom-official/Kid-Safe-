package com.example.kidsafe.parent

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import java.util.concurrent.Executors

private const val DB_NAME = "kidsafe_notifications.db"
private const val DB_VERSION = 1
private const val TABLE = "notifications"

/** The screen shows at most this many (newest first). Everything is still kept in the database. */
private const val MAX_SHOWN = 2000

/** One saved alert: what the parent was told about, and when it happened. */
data class SavedNotification(
    val id: String,
    val childId: String,
    val childName: String,
    val type: String,
    val title: String,
    val text: String,
    val time: Long,
)

private class NotificationDbHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE $TABLE (" +
                "id TEXT PRIMARY KEY, " +
                "owner TEXT NOT NULL, " +
                "child_id TEXT NOT NULL, " +
                "child_name TEXT NOT NULL, " +
                "type TEXT NOT NULL, " +
                "title TEXT NOT NULL, " +
                "body TEXT NOT NULL, " +
                "ts INTEGER NOT NULL)",
        )
        db.execSQL("CREATE INDEX idx_owner_ts ON $TABLE(owner, ts DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Version 1: nothing to migrate yet.
    }
}

/**
 * Keeps every alert notification this phone has received, in a small database on the phone.
 * It is saved even if Android notifications are switched off, so nothing is lost.
 * All reading and writing happens on a background thread.
 */
object NotificationStore {

    private val io = Executors.newSingleThreadExecutor()

    @Volatile
    private var instance: SQLiteOpenHelper? = null

    /** Goes up after every change, so an open history screen refreshes by itself. */
    var version by mutableIntStateOf(0)
        private set

    private fun helper(context: Context): SQLiteOpenHelper =
        instance ?: synchronized(this) {
            instance ?: NotificationDbHelper(context.applicationContext).also { instance = it }
        }

    /** Saves one alert. The same event is never saved twice. */
    fun add(
        context: Context,
        owner: String,
        childId: String,
        childName: String,
        type: String,
        title: String,
        text: String,
        time: Long,
    ) {
        val app = context.applicationContext
        io.execute {
            try {
                val values = ContentValues()
                values.put("id", "$owner|$childId|$type|$time")
                values.put("owner", owner)
                values.put("child_id", childId)
                values.put("child_name", childName)
                values.put("type", type)
                values.put("title", title)
                values.put("body", text)
                values.put("ts", time)
                val row = helper(app).writableDatabase
                    .insertWithOnConflict(TABLE, null, values, SQLiteDatabase.CONFLICT_IGNORE)
                if (row != -1L) version++
            } catch (e: Exception) {
                // The history is best-effort: it must never stop an alert from being shown.
            }
        }
    }

    /**
     * Reads the newest alerts of this parent account, then calls [onLoaded] with the list and
     * the total number saved. [onLoaded] runs on a background thread.
     */
    fun load(
        context: Context,
        owner: String,
        onLoaded: (items: List<SavedNotification>, total: Int) -> Unit,
    ) {
        val app = context.applicationContext
        io.execute {
            val items = ArrayList<SavedNotification>()
            var total = 0
            try {
                val db = helper(app).readableDatabase
                db.rawQuery("SELECT COUNT(*) FROM $TABLE WHERE owner = ?", arrayOf(owner)).use { c ->
                    if (c.moveToFirst()) total = c.getInt(0)
                }
                db.rawQuery(
                    "SELECT id, child_id, child_name, type, title, body, ts FROM $TABLE " +
                        "WHERE owner = ? ORDER BY ts DESC LIMIT $MAX_SHOWN",
                    arrayOf(owner),
                ).use { c ->
                    while (c.moveToNext()) {
                        items.add(
                            SavedNotification(
                                id = c.getString(0),
                                childId = c.getString(1),
                                childName = c.getString(2),
                                type = c.getString(3),
                                title = c.getString(4),
                                text = c.getString(5),
                                time = c.getLong(6),
                            ),
                        )
                    }
                }
            } catch (e: Exception) {
                // Show whatever could be read.
            }
            onLoaded(items, total)
        }
    }
}
