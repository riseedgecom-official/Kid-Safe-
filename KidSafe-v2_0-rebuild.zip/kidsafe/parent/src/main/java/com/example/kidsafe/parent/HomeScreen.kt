package com.example.kidsafe.parent

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.kidsafe.core.Col
import com.example.kidsafe.core.Fmt
import com.example.kidsafe.core.PairingCode
import com.example.kidsafe.ui.Avatar
import com.example.kidsafe.ui.Banner
import com.example.kidsafe.ui.BatteryPill
import com.example.kidsafe.ui.EmptyState
import com.example.kidsafe.ui.HeroCard
import com.example.kidsafe.ui.KsCard
import com.example.kidsafe.ui.KsScreen
import com.example.kidsafe.ui.Muted
import com.example.kidsafe.ui.OutlineButton
import com.example.kidsafe.ui.Pill
import com.example.kidsafe.ui.SectionTitle
import com.example.kidsafe.ui.Tone
import com.example.kidsafe.ui.agoText
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.delay
import java.util.Date

private enum class Tab { Family, Alerts, Account }

private fun notificationsAllowed(ctx: Context): Boolean =
    NotificationManagerCompat.from(ctx).areNotificationsEnabled()

/** Signed-in parent: three tabs, and a dashboard for each child. */
@Composable
fun ParentHome(uid: String, email: String?, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { FirebaseFirestore.getInstance() }

    var children by remember { mutableStateOf<List<ChildInfo>>(emptyList()) }
    var pairingCode by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(Tab.Family) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var section by remember { mutableStateOf<Section?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var notifAllowed by remember { mutableStateOf(notificationsAllowed(ctx)) }

    // Keep listening for SOS / arrived / left / battery in the background (asks for notification permission first).
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notifAllowed = notificationsAllowed(ctx)
        ContextCompat.startForegroundService(ctx, Intent(ctx, AlertService::class.java))
    }
    LaunchedEffect(Unit) {
        val needsAsk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsAsk) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AlertService::class.java))
        }
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { notifAllowed = notificationsAllowed(ctx) }

    // "5 minutes ago" texts stay fresh even if nothing new arrives.
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = System.currentTimeMillis()
        }
    }

    // Live updates: the list refreshes whenever a child's data changes.
    DisposableEffect(uid) {
        val registration = db.collection(Col.CHILDREN)
            .whereEqualTo("parentUid", uid)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    error = e.localizedMessage
                    return@addSnapshotListener
                }
                error = null
                children = snap?.documents?.map { it.toChild() }.orEmpty()
            }
        onDispose { registration.remove() }
    }

    val selected = children.firstOrNull { it.id == selectedId }

    // The selected child was removed (maybe from another phone): go back to the list.
    LaunchedEffect(selected == null, selectedId) {
        if (selectedId != null && selected == null) {
            selectedId = null
            section = null
        }
    }

    if (selected != null) {
        val open = section
        if (open == null) {
            ChildDashboard(
                child = selected,
                onBack = { selectedId = null },
                onOpen = { section = it },
                onRemoved = { selectedId = null },
            )
        } else {
            val back = { section = null }
            when (open) {
                Section.Usage -> UsageScreen(selected, back)
                Section.Places -> PlacesScreen(selected, back)
                Section.History -> HistoryScreen(selected, back)
                Section.Web -> WebFilterScreen(selected, back)
                Section.Share -> ScreenShareScreen(selected, back)
                Section.Chat -> ChatScreen(selected, uid, back)
            }
        }
        return
    }

    BackHandler(enabled = tab != Tab.Family) { tab = Tab.Family }

    KsScreen(
        title = when (tab) {
            Tab.Family -> "KidSafe"
            Tab.Alerts -> "Alerts"
            Tab.Account -> "Account"
        },
        floatingActionButton = {
            if (tab == Tab.Family) {
                ExtendedFloatingActionButton(onClick = {
                    createPairing(db, uid, onCode = { pairingCode = it }, onError = { error = it })
                }) { Text("Add child") }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == Tab.Family,
                    onClick = { tab = Tab.Family },
                    icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                    label = { Text("Family") },
                )
                NavigationBarItem(
                    selected = tab == Tab.Alerts,
                    onClick = { tab = Tab.Alerts },
                    icon = { Icon(Icons.Filled.Notifications, contentDescription = null) },
                    label = { Text("Alerts") },
                )
                NavigationBarItem(
                    selected = tab == Tab.Account,
                    onClick = { tab = Tab.Account },
                    icon = { Icon(Icons.Filled.Person, contentDescription = null) },
                    label = { Text("Account") },
                )
            }
        },
    ) { padding ->
        when (tab) {
            Tab.Family -> FamilyTab(
                padding = padding,
                children = children,
                now = now,
                error = error,
                notifAllowed = notifAllowed,
                onOpenChild = {
                    section = null
                    selectedId = it.id
                },
            )
            Tab.Alerts -> AlertsTab(uid, padding)
            Tab.Account -> AccountTab(padding, email, notifAllowed, onSignOut)
        }
    }

    pairingCode?.let { code ->
        AlertDialog(
            onDismissRequest = { pairingCode = null },
            confirmButton = { TextButton(onClick = { pairingCode = null }) { Text("Done") } },
            dismissButton = { TextButton(onClick = { shareCode(ctx, code) }) { Text("Share code") } },
            title = { Text("Pairing code") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(code, style = MaterialTheme.typography.displaySmall, fontFamily = FontFamily.Monospace)
                    Text("Enter this code on your child's phone within ${PairingCode.TTL_MINUTES} minutes.")
                }
            },
        )
    }
}

private fun shareCode(ctx: Context, code: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(
            Intent.EXTRA_TEXT,
            "KidSafe pairing code: $code (valid for ${PairingCode.TTL_MINUTES} minutes)",
        )
    }
    runCatching { ctx.startActivity(Intent.createChooser(send, "Share pairing code")) }
}

private fun createPairing(
    db: FirebaseFirestore,
    uid: String,
    onCode: (String) -> Unit,
    onError: (String) -> Unit,
) {
    val code = PairingCode.generate()
    val expires = Timestamp(Date(System.currentTimeMillis() + PairingCode.TTL_MINUTES * 60_000L))
    db.collection(Col.PAIRINGS).document(code)
        .set(
            mapOf(
                "parentUid" to uid,
                "used" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "expiresAt" to expires,
            ),
        )
        .addOnSuccessListener { onCode(code) }
        .addOnFailureListener { onError(it.localizedMessage ?: "Could not create code.") }
}

// ---------------------------------------------------------------------------------------------
// Family tab
// ---------------------------------------------------------------------------------------------

@Composable
private fun FamilyTab(
    padding: PaddingValues,
    children: List<ChildInfo>,
    now: Long,
    error: String?,
    notifAllowed: Boolean,
    onOpenChild: (ChildInfo) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 4.dp, bottom = 96.dp),
    ) {
        item {
            HeroCard {
                Text("Your family, connected", style = MaterialTheme.typography.titleLarge)
                Text(
                    "A safer digital life starts with staying connected.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "${children.size} linked ${if (children.size == 1) "child" else "children"}",
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
        if (!notifAllowed) {
            item {
                Banner(
                    "Notifications are off for KidSafe, so you won't hear about an SOS while the app is closed. " +
                        "Turn them on in the Account tab.",
                    tone = Tone.Warning,
                )
            }
        }
        error?.let { item { Banner(it, tone = Tone.Danger) } }
        item { SectionTitle("Family dashboard") }
        if (children.isEmpty()) {
            item {
                EmptyState(
                    "👨‍👩‍👧",
                    "Add your first child",
                    "Tap the Add child button below to create a secure pairing code, then enter it on the Child app.",
                )
            }
        }
        items(children, key = { it.id }) { c ->
            ChildCard(c, now) { onOpenChild(c) }
        }
    }
}

@Composable
private fun ChildCard(c: ChildInfo, now: Long, onClick: () -> Unit) {
    val quiet = c.isQuiet(now)
    val active = c.lastActive()
    KsCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Avatar(c.name)
            Column(Modifier.weight(1f)) {
                Text(c.name, style = MaterialTheme.typography.titleLarge)
                if (c.lat != null && c.lng != null) {
                    Muted("📍 Last location ${agoText(c.locTime)}")
                } else {
                    Muted("No location received yet.")
                }
            }
            BatteryPill(c.battery)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            when {
                active == null -> Pill("Waiting for first signal", Tone.Neutral)
                quiet -> Pill("Quiet · ${agoText(active)}", Tone.Warning)
                else -> Pill("Active · ${agoText(active)}", Tone.Success)
            }
            if (c.moving && !quiet) Pill("Moving", Tone.Info)
        }
        c.usageTodayOrNull()?.let { Muted("📊 Screen time today: ${Fmt.duration(it)}") }
        c.eventLine()?.let { Banner(it.text, tone = it.tone) }
    }
}

// ---------------------------------------------------------------------------------------------
// Account tab
// ---------------------------------------------------------------------------------------------

@Composable
private fun AccountTab(
    padding: PaddingValues,
    email: String?,
    notifAllowed: Boolean,
    onSignOut: () -> Unit,
) {
    val ctx = LocalContext.current
    LazyColumn(
        modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp),
    ) {
        item {
            KsCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Avatar(email ?: "Parent")
                    Column(Modifier.weight(1f)) {
                        Text(email ?: "Signed in", style = MaterialTheme.typography.titleMedium)
                        Muted("Parent account")
                    }
                }
            }
        }
        if (!notifAllowed) {
            item {
                Banner(
                    "Notifications are off. Without them you won't be told about an SOS, arrivals " +
                        "or low battery while the app is closed.",
                    tone = Tone.Warning,
                    title = "Turn on notifications",
                    action = {
                        TextButton(onClick = {
                            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                            runCatching { ctx.startActivity(intent) }
                        }) { Text("Open settings") }
                    },
                )
            }
        }
        item {
            KsCard {
                Text("What your child's phone shares", style = MaterialTheme.typography.titleMedium)
                Muted(
                    "• Location and battery — with a permanent notification on their phone\n" +
                        "• App usage time — only if they allow it in Settings\n" +
                        "• Blocked website names — only while web protection is on\n" +
                        "• Their screen — only when they choose to share it\n" +
                        "• Messages they send you in the chat\n\n" +
                        "Anything you trigger from here (like “Locate now”) shows a notice on their phone.",
                )
            }
        }
        item { OutlineButton("Sign out", onClick = onSignOut, modifier = Modifier.fillMaxWidth()) }
        item { Muted("KidSafe Parent 2.0") }
    }
}
