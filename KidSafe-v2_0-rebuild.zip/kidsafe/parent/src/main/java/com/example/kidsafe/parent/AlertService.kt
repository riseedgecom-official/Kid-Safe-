package com.example.kidsafe.parent

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.kidsafe.core.Alerts
import com.example.kidsafe.core.Col
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

/**
 * Free alternative to push messages: while the parent is signed in, this service keeps a live
 * connection to Firestore and shows a notification for SOS / arrived / left / battery / check-in
 * / screen-time events.
 */
class AlertService : Service() {

    private var registration: ListenerRegistration? = null
    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("alert_prefs", Context.MODE_PRIVATE)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Alerts are on", NotificationManager.IMPORTANCE_LOW),
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERTS, "Safety alerts", NotificationManager.IMPORTANCE_HIGH),
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(
                this, STATUS_ID, statusNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST,
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        registration?.remove()
        registration = FirebaseFirestore.getInstance()
            .collection(Col.CHILDREN)
            .whereEqualTo("parentUid", uid)
            .addSnapshotListener { snap, e ->
                if (e != null || snap == null) return@addSnapshotListener
                snap.documents.forEach { handle(it, uid) }
            }
        return START_STICKY
    }

    override fun onDestroy() {
        registration?.remove()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("UNCHECKED_CAST")
    private fun handle(doc: DocumentSnapshot, owner: String) {
        val ev = doc.get("lastEvent") as? Map<String, Any?> ?: return
        val type = ev["type"] as? String ?: return
        val ts = (ev["ts"] as? Timestamp)?.toDate()?.time ?: return

        val key = "seen_${doc.id}"
        val seen = prefs.getLong(key, -1L)
        val firstTime = seen == -1L
        if (!firstTime && ts <= seen) return
        prefs.edit().putLong(key, ts).apply()

        val child = doc.getString("name") ?: "Your child"
        val copy = Alerts.copy(
            type = type,
            child = child,
            place = ev["place"] as? String,
            battery = (ev["battery"] as? Number)?.toInt(),
            goalMinutes = (ev["goalMinutes"] as? Number)?.toInt(),
            usedMinutes = (ev["usedMinutes"] as? Number)?.toInt(),
        ) ?: return

        // Every alert goes into the notification history (even if Android notifications are off).
        NotificationStore.add(this, owner, doc.id, child, type, copy.title, copy.text, ts)

        // First time we see this child: only remember the latest event, don't alert about old news.
        if (firstTime) return
        notifyAlert(copy.title, copy.text)
    }

    private fun notifyAlert(title: String, text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return

        val n = NotificationCompat.Builder(this, CH_ALERTS)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp())
            .build()
        getSystemService(NotificationManager::class.java)
            .notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }

    private fun statusNotification(): Notification =
        NotificationCompat.Builder(this, CH_STATUS)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Safety alerts are on")
            .setContentText("You will be notified about SOS, arrivals/departures and low battery.")
            .setOngoing(true)
            .setContentIntent(openApp())
            .build()

    private fun openApp(): PendingIntent =
        PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )

    private companion object {
        const val CH_STATUS = "alerts_status"
        const val CH_ALERTS = "alerts"
        const val STATUS_ID = 2001
    }
}
