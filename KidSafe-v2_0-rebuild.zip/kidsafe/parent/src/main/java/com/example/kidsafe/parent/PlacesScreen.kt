package com.example.kidsafe.parent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.example.kidsafe.core.Input
import com.example.kidsafe.ui.Banner
import com.example.kidsafe.ui.ChoiceChips
import com.example.kidsafe.ui.EmptyState
import com.example.kidsafe.ui.KsCard
import com.example.kidsafe.ui.KsScreen
import com.example.kidsafe.ui.Muted
import com.example.kidsafe.ui.OutlineButton
import com.example.kidsafe.ui.Tone
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

data class Place(val id: String, val name: String, val lat: Double, val lng: Double, val radius: Int)

private fun DocumentSnapshot.toPlace(): Place? {
    val name = getString("name") ?: return null
    val lat = getDouble("lat") ?: return null
    val lng = getDouble("lng") ?: return null
    return Place(id, name, lat, lng, (getLong("radius") ?: 300L).toInt())
}

/** Places that raise an "arrived" / "left" alert. */
@Composable
fun PlacesScreen(child: ChildInfo, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var places by remember { mutableStateOf<List<Place>>(emptyList()) }
    var showAdd by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    val placesRef = remember(child.id) {
        db.collection(Col.CHILDREN).document(child.id).collection(Col.PLACES)
    }

    DisposableEffect(child.id) {
        val registration = placesRef.addSnapshotListener { snap, e ->
            if (e != null) {
                error = e.localizedMessage
                return@addSnapshotListener
            }
            places = snap?.documents?.mapNotNull { it.toPlace() }.orEmpty()
        }
        onDispose { registration.remove() }
    }

    KsScreen(
        title = "${child.name} · Safe places",
        onBack = onBack,
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showAdd = true }) { Text("Add place") }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 4.dp, bottom = 96.dp),
        ) {
            item {
                Muted("You get an alert when ${child.name} arrives at or leaves one of these places.")
            }
            error?.let { item { Banner(it, tone = Tone.Danger) } }
            if (places.isEmpty()) {
                item {
                    EmptyState(
                        "📍",
                        "No places yet",
                        "Tap “Add place” (for example Home or School).",
                    )
                }
            }
            items(places, key = { it.id }) { p ->
                KsCard(padding = 12.dp) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Muted("${p.radius} m around this spot")
                        }
                        TextButton(onClick = { placesRef.document(p.id).delete() }) { Text("Delete") }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddPlaceDialog(
            child = child,
            onDismiss = { showAdd = false },
            onSave = { name, lat, lng, radius ->
                placesRef.add(
                    mapOf(
                        "name" to name,
                        "lat" to lat,
                        "lng" to lng,
                        "radius" to radius,
                        "createdAt" to FieldValue.serverTimestamp(),
                    ),
                )
                showAdd = false
            },
        )
    }
}

@Composable
private fun AddPlaceDialog(
    child: ChildInfo,
    onDismiss: () -> Unit,
    onSave: (name: String, lat: Double, lng: Double, radius: Int) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var coords by remember { mutableStateOf("") }
    var radius by remember { mutableStateOf(300) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add place") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name (Home, School…)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = coords,
                    onValueChange = { coords = it },
                    label = { Text("Coordinates: lat, lng") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Muted(
                    "Tip: in Google Maps, long-press the place, tap the numbers at the top to copy, then paste here.",
                )
                if (child.lat != null && child.lng != null) {
                    OutlineButton(
                        text = "Use ${child.name}'s last location",
                        onClick = { coords = "${child.lat}, ${child.lng}" },
                    )
                }
                ChoiceChips(
                    options = listOf(150, 300, 500),
                    selected = radius,
                    label = { "$it m" },
                    onSelect = { radius = it },
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val ll = Input.parseCoords(coords)
                if (name.isBlank()) {
                    error = "Please enter a name."
                } else if (ll == null) {
                    error = "Enter coordinates like 23.8103, 90.4125"
                } else {
                    onSave(name.trim(), ll.first, ll.second, radius)
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
