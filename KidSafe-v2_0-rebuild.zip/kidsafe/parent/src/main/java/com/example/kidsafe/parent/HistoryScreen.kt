package com.example.kidsafe.parent

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.example.kidsafe.core.Fmt
import com.example.kidsafe.core.RoutePoint
import com.example.kidsafe.core.RouteStops
import com.example.kidsafe.ui.Banner
import com.example.kidsafe.ui.ChoiceChips
import com.example.kidsafe.ui.EmptyState
import com.example.kidsafe.ui.KsCard
import com.example.kidsafe.ui.KsScreen
import com.example.kidsafe.ui.Loading
import com.example.kidsafe.ui.Muted
import com.example.kidsafe.ui.PrimaryButton
import com.example.kidsafe.ui.SectionTitle
import com.example.kidsafe.ui.Tone
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos

private fun DocumentSnapshot.toPoint(): RoutePoint? {
    val lat = getDouble("lat") ?: return null
    val lng = getDouble("lng") ?: return null
    val time = getTimestamp("ts")?.toDate()?.time ?: return null
    return RoutePoint(lat, lng, time, getLong("battery")?.toInt())
}

private fun dayRange(daysAgo: Int): Pair<Timestamp, Timestamp> {
    val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, -daysAgo)
    }
    val start = cal.time
    cal.add(Calendar.DAY_OF_YEAR, 1)
    return Timestamp(start) to Timestamp(cal.time)
}

private fun dayLabel(daysAgo: Int): String = when (daysAgo) {
    0 -> "Today"
    1 -> "Yesterday"
    else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(
        Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -daysAgo) }.time,
    )
}

private fun openPin(ctx: Context, lat: Double, lng: Double, label: String) {
    val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(label)})")
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
}

/** Opens Google Maps with the day's route (start, up to 9 waypoints, end). */
private fun openRoute(ctx: Context, points: List<RoutePoint>) {
    if (points.isEmpty()) return
    val s = RouteStops.sample(points, 11)
    val origin = s.first()
    val dest = s.last()
    val via = s.drop(1).dropLast(1)
    val url = buildString {
        append("https://www.google.com/maps/dir/?api=1")
        append("&origin=${origin.lat},${origin.lng}")
        append("&destination=${dest.lat},${dest.lng}")
        if (via.isNotEmpty()) {
            append("&waypoints=")
            append(via.joinToString("%7C") { "${it.lat},${it.lng}" })
        }
    }
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

/** One day of location points: a simple drawing of the path, plus a timeline of stops. */
@Composable
fun HistoryScreen(child: ChildInfo, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { FirebaseFirestore.getInstance() }
    var dayIndex by remember { mutableStateOf(0) }
    var points by remember { mutableStateOf<List<RoutePoint>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    BackHandler(onBack = onBack)

    DisposableEffect(child.id, dayIndex) {
        loaded = false
        points = emptyList()
        val (start, end) = dayRange(dayIndex)
        val registration = db.collection(Col.CHILDREN).document(child.id).collection(Col.LOCATIONS)
            .whereGreaterThanOrEqualTo("ts", start)
            .whereLessThan("ts", end)
            .orderBy("ts")
            .limit(1000)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    error = e.localizedMessage
                    return@addSnapshotListener
                }
                points = snap?.documents?.mapNotNull { it.toPoint() }.orEmpty()
                loaded = true
            }
        onDispose { registration.remove() }
    }

    val stops = remember(points) { RouteStops.build(points) }

    KsScreen(title = "${child.name} · Location history", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp),
        ) {
            item {
                ChoiceChips(
                    options = (0..6).toList(),
                    selected = dayIndex,
                    label = { dayLabel(it) },
                    onSelect = { dayIndex = it },
                )
            }
            error?.let { item { Banner(it, tone = Tone.Danger) } }

            if (!loaded) {
                item { Loading() }
            } else if (points.isEmpty()) {
                item { EmptyState("🗺️", "No location points", "Nothing was recorded for this day.") }
            } else {
                item {
                    Text(
                        "${points.size} location points · ${timeFormat.format(Date(points.first().time))} " +
                            "to ${timeFormat.format(Date(points.last().time))}",
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
                item {
                    KsCard(padding = 0.dp) {
                        RouteCanvas(points, Modifier.fillMaxWidth().height(240.dp))
                    }
                }
                item {
                    Muted(
                        "🟢 start  🔴 latest. This is a simple drawing of the path. " +
                            "The button below shows the real map (Google may snap the path to roads).",
                    )
                }
                item {
                    PrimaryButton(
                        text = "Open route in Google Maps",
                        onClick = { openRoute(ctx, points) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                item { SectionTitle("Timeline") }
                items(stops) { s ->
                    val title = if (s.stayed) {
                        "${timeFormat.format(Date(s.fromTime))} – ${timeFormat.format(Date(s.toTime))}" +
                            "  (${Fmt.duration(s.durationMs)})"
                    } else {
                        timeFormat.format(Date(s.fromTime))
                    }
                    val battery = s.battery?.let { " · 🔋$it%" }.orEmpty()
                    KsCard(padding = 12.dp) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(title, style = MaterialTheme.typography.titleSmall)
                                Muted((if (s.stayed) "Stayed here" else "Passing by") + battery)
                            }
                            TextButton(onClick = {
                                openPin(ctx, s.lat, s.lng, "${child.name} ${timeFormat.format(Date(s.fromTime))}")
                            }) { Text("Map") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RouteCanvas(points: List<RoutePoint>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.primary
    val startColor = Color(0xFF2E7D32)
    val endColor = Color(0xFFC62828)

    Canvas(modifier) {
        if (points.isEmpty()) return@Canvas
        val pad = 28f
        val minLat = points.minOf { it.lat }
        val maxLat = points.maxOf { it.lat }
        val minLng = points.minOf { it.lng }
        val maxLng = points.maxOf { it.lng }
        val kx = cos(Math.toRadians((minLat + maxLat) / 2)).toFloat()

        val w = ((maxLng - minLng) * kx).toFloat().coerceAtLeast(1e-6f)
        val h = (maxLat - minLat).toFloat().coerceAtLeast(1e-6f)
        val availW = size.width - 2 * pad
        val availH = size.height - 2 * pad
        val scale = minOf(availW / w, availH / h)
        val offX = pad + (availW - w * scale) / 2
        val offY = pad + (availH - h * scale) / 2

        fun at(p: RoutePoint) = Offset(
            offX + ((p.lng - minLng) * kx).toFloat() * scale,
            offY + (maxLat - p.lat).toFloat() * scale,
        )

        val path = Path()
        points.forEachIndexed { i, p ->
            val o = at(p)
            if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
        }
        drawPath(path, lineColor, style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(startColor, radius = 12f, center = at(points.first()))
        drawCircle(endColor, radius = 12f, center = at(points.last()))
    }
}
