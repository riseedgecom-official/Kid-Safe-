package com.example.kidsafe.parent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.example.kidsafe.core.EventType
import com.example.kidsafe.core.Fmt
import com.example.kidsafe.core.SettingsDoc
import com.example.kidsafe.ui.ActionTile
import com.example.kidsafe.ui.Avatar
import com.example.kidsafe.ui.Banner
import com.example.kidsafe.ui.BatteryPill
import com.example.kidsafe.ui.KsCard
import com.example.kidsafe.ui.KsScreen
import com.example.kidsafe.ui.Muted
import com.example.kidsafe.ui.OutlineButton
import com.example.kidsafe.ui.Pill
import com.example.kidsafe.ui.PrimaryButton
import com.example.kidsafe.ui.SectionTitle
import com.example.kidsafe.ui.Tone
import com.example.kidsafe.ui.agoText
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.delay

/** The tools available for one child. */
enum class Section { Usage, Places, History, Web, Share, Chat }

private enum class Locate { Idle, Pending, NoAnswer, Done }

/** One child at a glance, with the buttons to every tool. */
@Composable
fun ChildDashboard(
    child: ChildInfo,
    onBack: () -> Unit,
    onOpen: (Section) -> Unit,
    onRemoved: () -> Unit,
) {
    val ctx = LocalContext.current
    val db = remember { FirebaseFirestore.getInstance() }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var locate by remember { mutableStateOf(Locate.Idle) }
    var baseline by remember { mutableLongStateOf(0L) }
    var locateError by remember { mutableStateOf<String?>(null) }
    var confirmRemove by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000)
            now = System.currentTimeMillis()
        }
    }

    // "Locate now" is answered when the child's phone reports anything newer than what we had when we asked.
    val active = child.lastActive()
    LaunchedEffect(locate, active) {
        if (locate == Locate.Pending && (active ?: 0L) > baseline) locate = Locate.Done
    }
    LaunchedEffect(locate) {
        if (locate == Locate.Pending) {
            delay(120_000)
            if (locate == Locate.Pending) locate = Locate.NoAnswer
        }
    }

    fun requestLocate() {
        baseline = active ?: 0L
        locate = Locate.Pending
        locateError = null
        db.collection(Col.CHILDREN).document(child.id)
            .collection(Col.SETTINGS).document(SettingsDoc.LOCATE)
            .set(mapOf("requestedAt" to FieldValue.serverTimestamp()))
            .addOnFailureListener {
                locate = Locate.Idle
                locateError = it.localizedMessage ?: "Could not send the request."
            }
    }

    val quiet = child.isQuiet(now)
    val usageToday = child.usageTodayOrNull()

    KsScreen(title = child.name, onBack = onBack) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp).padding(top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // ---- Where are they? ----
            KsCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Avatar(child.name, size = 52.dp)
                    Column(Modifier.weight(1f)) {
                        Text(child.name, style = MaterialTheme.typography.titleLarge)
                        when {
                            active == null -> Muted("Waiting for the first signal")
                            quiet -> Muted("Last signal ${agoText(active)}")
                            else -> Muted("Active ${agoText(active)}")
                        }
                    }
                    BatteryPill(child.battery)
                }

                if (child.lat != null && child.lng != null) {
                    val accuracy = child.accuracyM?.let { " · accurate to about $it m" }.orEmpty()
                    Text(
                        "📍 Last location ${agoText(child.locTime)}$accuracy",
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    if (child.moving && !quiet) Pill("Moving", Tone.Info)
                } else {
                    Text("No location received yet.", style = MaterialTheme.typography.bodyLarge)
                }

                if (quiet) {
                    Banner(
                        "No signal from ${child.name}'s phone for a while. It may be switched off, offline " +
                            "or out of battery.",
                        tone = Tone.Warning,
                    )
                }

                PrimaryButton(
                    text = when (locate) {
                        Locate.Pending -> "Asking ${child.name}'s phone…"
                        else -> "📍 Locate now"
                    },
                    enabled = locate != Locate.Pending,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { requestLocate() },
                )
                when (locate) {
                    Locate.Pending -> Muted("Waiting for a fresh location. This usually takes a few seconds.")
                    Locate.Done -> Banner("Fresh location received ✅", tone = Tone.Success)
                    Locate.NoAnswer -> Banner(
                        "No answer yet. ${child.name}'s phone may be off or have no internet. " +
                            "The request stays open for a few minutes, so it may still arrive.",
                        tone = Tone.Warning,
                    )
                    Locate.Idle -> Muted("${child.name} sees a notice on their phone when you ask.")
                }
                locateError?.let { Banner(it, tone = Tone.Danger) }

                if (child.lat != null && child.lng != null) {
                    OutlineButton(
                        text = "Open in Maps",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { openMap(ctx, child.lat, child.lng, child.name) },
                    )
                }
            }

            // ---- Latest event ----
            child.eventLine()?.let { line ->
                Banner(line.text, tone = line.tone, title = "Latest")
                val eLat = child.eventLat
                val eLng = child.eventLng
                if (eLat != null && eLng != null &&
                    (child.eventType == EventType.SOS || child.eventType == EventType.CHECK_IN)
                ) {
                    PrimaryButton(
                        text = if (child.eventType == EventType.SOS) "Open SOS location" else "Open check-in location",
                        danger = child.eventType == EventType.SOS,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { openMap(ctx, eLat, eLng, "${child.name} ${child.eventType}") },
                    )
                }
            }

            // ---- Tools ----
            SectionTitle("Tools")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionTile(
                    emoji = "📊",
                    title = "App usage",
                    subtitle = usageToday?.let { "Today ${Fmt.duration(it)}" } ?: "Screen-time goal",
                    modifier = Modifier.weight(1f),
                    onClick = { onOpen(Section.Usage) },
                )
                ActionTile(
                    emoji = "🗺️",
                    title = "History",
                    subtitle = "Route & stops",
                    modifier = Modifier.weight(1f),
                    onClick = { onOpen(Section.History) },
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionTile(
                    emoji = "📍",
                    title = "Safe places",
                    subtitle = "Arrive & leave alerts",
                    modifier = Modifier.weight(1f),
                    onClick = { onOpen(Section.Places) },
                )
                ActionTile(
                    emoji = "🛡️",
                    title = "Web filter",
                    subtitle = "Block unsafe sites",
                    modifier = Modifier.weight(1f),
                    onClick = { onOpen(Section.Web) },
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionTile(
                    emoji = "🖥️",
                    title = "Screen share",
                    subtitle = "When they share",
                    modifier = Modifier.weight(1f),
                    onClick = { onOpen(Section.Share) },
                )
                ActionTile(
                    emoji = "💬",
                    title = "Chat",
                    subtitle = "Talk to ${child.name}",
                    modifier = Modifier.weight(1f),
                    onClick = { onOpen(Section.Chat) },
                )
            }

            TextButton(onClick = { confirmRemove = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Remove this child")
            }
        }
    }

    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            title = { Text("Remove ${child.name}?") },
            text = { Text("This unlinks the child from your account and hides their data.") },
            confirmButton = {
                TextButton(onClick = {
                    db.collection(Col.CHILDREN).document(child.id).delete()
                    confirmRemove = false
                    onRemoved()
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Cancel") } },
        )
    }
}
