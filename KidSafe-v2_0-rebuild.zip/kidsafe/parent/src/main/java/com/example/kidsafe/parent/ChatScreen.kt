package com.example.kidsafe.parent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.ChatMessage
import com.example.kidsafe.ui.ChatBubble
import com.example.kidsafe.ui.ChatInputBar
import com.example.kidsafe.ui.EmptyState
import com.example.kidsafe.ui.KsScreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One-tap preset replies — shown as real buttons above the text field. */
private val QUICK_REPLIES = listOf(
    "👍 Okay, thank you",
    "📞 Calling you now",
    "🚗 Drive safe",
    "❤️ Love you",
)

/** Chat with one linked child. */
@Composable
fun ChatScreen(child: ChildInfo, parentUid: String, onBack: () -> Unit) {
    val repo = remember { ChatRepository() }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    val listState = rememberLazyListState()
    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }

    BackHandler(onBack = onBack)

    DisposableEffect(child.id) {
        val reg = repo.listen(child.id) { messages = it }
        onDispose { reg.remove() }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    KsScreen(
        title = "💬 ${child.name}",
        onBack = onBack,
        bottomBar = { ChatInputBar(QUICK_REPLIES) { repo.send(child.id, parentUid, it) } },
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 8.dp),
        ) {
            if (messages.isEmpty()) {
                item { EmptyState("👋", "No messages yet", "Say hi to ${child.name}.") }
            }
            items(messages, key = { it.id }) { m ->
                // On the parent's screen, a message the parent sent sits on the right.
                ChatBubble(text = m.text, timeText = timeFormat.format(Date(m.time)), mine = !m.fromChild)
            }
        }
    }
}
