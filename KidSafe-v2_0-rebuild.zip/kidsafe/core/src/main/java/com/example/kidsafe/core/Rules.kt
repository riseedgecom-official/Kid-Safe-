package com.example.kidsafe.core

/** Low-battery alert: fires once per discharge, re-arms after charging or recovering. */
object BatteryAlert {
    const val LOW_PERCENT = 15
    const val REARM_PERCENT = 25

    data class Result(val alert: Boolean, val armed: Boolean)

    /**
     * @param armed whether an alert may fire now (store the returned value and pass it back next time)
     * @param level battery percent 0..100, or a negative number when unknown
     */
    fun evaluate(level: Int, charging: Boolean, armed: Boolean): Result {
        if (level < 0) return Result(alert = false, armed = armed)
        if (charging || level >= REARM_PERCENT) return Result(alert = false, armed = true)
        if (armed && level <= LOW_PERCENT) return Result(alert = true, armed = false)
        return Result(alert = false, armed = armed)
    }
}

/** Daily screen-time goal. A goal is a gentle limit: the child and the parent are told, nothing is blocked. */
object ScreenTimeGoal {
    /** Minutes offered to the parent. 0 = no goal. */
    val PRESETS = listOf(0, 30, 60, 90, 120, 180, 240, 360)

    fun isExceeded(totalMs: Long, goalMinutes: Int): Boolean =
        goalMinutes > 0 && totalMs >= goalMinutes * 60_000L

    /** 0f..1f for a progress bar. */
    fun progress(totalMs: Long, goalMinutes: Int): Float =
        if (goalMinutes <= 0) 0f else (totalMs.toFloat() / (goalMinutes * 60_000f)).coerceIn(0f, 1f)
}

/** What a "Locate now" request from the parent should do on the child's phone. */
object LocateRequest {
    /** A request older than this is ignored (the phone was probably offline for a long time). */
    const val MAX_AGE_MS = 10 * 60_000L

    fun shouldHandle(requestedAtMs: Long, lastHandledMs: Long, nowMs: Long): Boolean =
        requestedAtMs > lastHandledMs && nowMs - requestedAtMs <= MAX_AGE_MS
}

/** Text helpers shared by both apps. */
object Fmt {
    /** 65 minutes -> "1h 5m"; 20 minutes -> "20m". */
    fun duration(ms: Long): String {
        val m = ms / 60_000L
        return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
    }

    /** Goal label: 0 -> "Off", 90 -> "1h 30m", 120 -> "2h", 30 -> "30m". */
    fun goal(minutes: Int): String = when {
        minutes <= 0 -> "Off"
        minutes < 60 -> "${minutes}m"
        minutes % 60 == 0 -> "${minutes / 60}h"
        else -> "${minutes / 60}h ${minutes % 60}m"
    }

    /** Short preview used for chat messages in alerts. */
    fun preview(text: String, max: Int = 80): String =
        if (text.length > max) text.take(max) + "…" else text
}

/** Parsing of what the parent types in. */
object Input {
    /** "https://www.Example.com/page?x=1" -> "example.com", or null if it doesn't look like a site. */
    fun normalizeDomain(input: String): String? {
        var s = input.trim().lowercase()
            .removePrefix("http://").removePrefix("https://").removePrefix("www.")
        s = s.substringBefore('/').substringBefore('?').substringBefore(':')
        return if (Regex("^[a-z0-9-]+(\\.[a-z0-9-]+)+\$").matches(s)) s else null
    }

    /** "23.8103, 90.4125" (as copied from Google Maps) -> lat/lng, or null if it doesn't look right. */
    fun parseCoords(text: String): Pair<Double, Double>? {
        val parts = text.split(",").map { it.trim() }
        if (parts.size != 2) return null
        val lat = parts[0].toDoubleOrNull() ?: return null
        val lng = parts[1].toDoubleOrNull() ?: return null
        return if (lat in -90.0..90.0 && lng in -180.0..180.0) lat to lng else null
    }
}

/** The words of each alert shown to the parent (notification + history). */
data class AlertCopy(val title: String, val text: String)

object Alerts {
    /**
     * Returns null for events that are not shown as a notification
     * (for example "child allowed location"), so they are not saved in the history either.
     */
    fun copy(
        type: String,
        child: String,
        place: String? = null,
        battery: Int? = null,
        goalMinutes: Int? = null,
        usedMinutes: Int? = null,
    ): AlertCopy? = when (type) {
        EventType.SOS -> AlertCopy("🚨 $child sent an SOS", "Open the app to see their location.")
        EventType.GEOFENCE_ENTER -> AlertCopy("📍 $child arrived", "Arrived at ${place ?: "a saved place"}")
        EventType.GEOFENCE_EXIT -> AlertCopy("🚶 $child left", "Left ${place ?: "a saved place"}")
        EventType.WEB_BLOCKED -> AlertCopy("🚫 $child tried a blocked site", "Blocked: ${place ?: "?"}")
        EventType.FILTER_OFF -> AlertCopy(
            "⚠️ $child turned off web protection",
            "The website filter is no longer active.",
        )
        EventType.NEED_TALK -> AlertCopy("💬 $child wants to talk", "Open the app and reach out to them.")
        EventType.SCREEN_SHARE_START -> AlertCopy(
            "🖥️ $child is sharing their screen",
            "Open the app to view it.",
        )
        EventType.CHAT_MESSAGE -> AlertCopy("💬 Message from $child", place.orEmpty())
        EventType.BATTERY_LOW -> AlertCopy(
            "🔋 $child's phone battery is low",
            if (battery != null) {
                "Battery is at $battery%. Location sharing stops if the phone runs out."
            } else {
                "Location sharing stops if the phone runs out."
            },
        )
        EventType.CHECK_IN -> AlertCopy("✅ $child checked in", "They are safe. Open the app to see where they are.")
        EventType.SCREEN_LIMIT -> AlertCopy(
            "⏳ $child reached today's screen-time goal",
            "Goal ${Fmt.goal(goalMinutes ?: 0)} · used ${Fmt.duration((usedMinutes ?: 0) * 60_000L)} today.",
        )
        else -> null
    }
}
