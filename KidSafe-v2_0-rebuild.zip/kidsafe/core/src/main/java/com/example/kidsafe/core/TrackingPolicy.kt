package com.example.kidsafe.core

/** How often the child's phone asks for a new location. */
enum class TrackingMode { STATIONARY, MOVING }

/** One location reading, without any Android types. */
data class Fix(val lat: Double, val lng: Double, val accuracyM: Float, val timeMs: Long)

/** What the service should do with a reading. */
data class TrackingDecision(
    /** False = ignore this reading completely (too imprecise, we already have a good recent one). */
    val accept: Boolean,
    /** True = also add a point to the location history (otherwise only "last location" is refreshed). */
    val saveHistory: Boolean,
    val mode: TrackingMode,
    /** True = the service should re-request location updates with the settings of [mode]. */
    val modeChanged: Boolean,
)

/**
 * Decides, reading by reading, how the child's location is shared. Goals:
 *  - while moving: a steady trail (a point every ~30-60 s)
 *  - while still: very little battery use, but the parent still sees "last seen" fresh, and the
 *    history still records that the child stayed somewhere (a point at least every 20 minutes)
 *  - ignore wildly imprecise readings (cell-tower jumps) so the route does not zig-zag
 */
class TrackingPolicy(
    private val movingStartM: Double = 50.0,
    private val stillRadiusM: Double = 40.0,
    private val historyMinMoveM: Double = 40.0,
    private val historyMaxGapMs: Long = 20 * 60_000L,
    private val maxGoodAccuracyM: Float = 150f,
    private val acceptImpreciseAfterMs: Long = 15 * 60_000L,
    private val stillReadingsToStop: Int = 2,
) {
    var mode: TrackingMode = TrackingMode.STATIONARY
        private set

    private var lastAccepted: Fix? = null
    private var lastSaved: Fix? = null
    private var stillCount = 0

    fun onFix(f: Fix): TrackingDecision {
        val prev = lastAccepted

        // 1. Too imprecise and we already have a recent decent reading: skip it.
        if (prev != null &&
            f.accuracyM > maxGoodAccuracyM &&
            f.timeMs - prev.timeMs < acceptImpreciseAfterMs
        ) {
            return TrackingDecision(accept = false, saveHistory = false, mode = mode, modeChanged = false)
        }

        // 2. Moving or still?
        val before = mode
        if (prev != null) {
            val d = Geo.distanceMeters(prev.lat, prev.lng, f.lat, f.lng)
            if (d >= movingStartM) {
                mode = TrackingMode.MOVING
                stillCount = 0
            } else if (mode == TrackingMode.MOVING) {
                if (d <= stillRadiusM) {
                    stillCount++
                    if (stillCount >= stillReadingsToStop) {
                        mode = TrackingMode.STATIONARY
                        stillCount = 0
                    }
                } else {
                    stillCount = 0
                }
            }
        }

        // 3. History point?
        val saved = lastSaved
        val save = saved == null ||
            Geo.distanceMeters(saved.lat, saved.lng, f.lat, f.lng) >= historyMinMoveM ||
            f.timeMs - saved.timeMs >= historyMaxGapMs

        lastAccepted = f
        if (save) lastSaved = f
        return TrackingDecision(accept = true, saveHistory = save, mode = mode, modeChanged = mode != before)
    }

    /** A reading the parent asked for ("Locate now"): always accepted and always saved. */
    fun onForcedFix(f: Fix): TrackingDecision {
        lastAccepted = f
        lastSaved = f
        return TrackingDecision(accept = true, saveHistory = true, mode = mode, modeChanged = false)
    }
}
