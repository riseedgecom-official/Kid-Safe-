package com.example.kidsafe.core

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Plain-Kotlin geography helpers (no Android classes, so they can be unit-tested anywhere). */
object Geo {
    private const val EARTH_RADIUS_M = 6_371_000.0

    /** Great-circle distance between two points, in metres (haversine). */
    fun distanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dp = p2 - p1
        val dl = Math.toRadians(lng2 - lng1)
        val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * EARTH_RADIUS_M * asin(min(1.0, sqrt(a)))
    }
}

/** One saved location point of the child's day. */
data class RoutePoint(val lat: Double, val lng: Double, val time: Long, val battery: Int?)

/** A group of consecutive nearby points: "the child was around here from X to Y". */
data class Stop(
    val lat: Double,
    val lng: Double,
    val fromTime: Long,
    val toTime: Long,
    val battery: Int?,
) {
    val durationMs: Long get() = toTime - fromTime
    val stayed: Boolean get() = durationMs >= RouteStops.STAY_MIN_MS
}

object RouteStops {
    /** Points within 100 m of each other count as "the same place". */
    const val STOP_RADIUS_M = 100.0

    /** 10+ minutes in one place counts as "stayed". */
    const val STAY_MIN_MS = 10 * 60_000L

    /** Groups consecutive nearby points into stops so the timeline stays short and readable. */
    fun build(points: List<RoutePoint>): List<Stop> {
        if (points.isEmpty()) return emptyList()
        val result = mutableListOf<Stop>()
        var first = points[0]
        var last = points[0]
        for (i in 1 until points.size) {
            val p = points[i]
            if (Geo.distanceMeters(first.lat, first.lng, p.lat, p.lng) <= STOP_RADIUS_M) {
                last = p
            } else {
                result += Stop(first.lat, first.lng, first.time, last.time, last.battery)
                first = p
                last = p
            }
        }
        result += Stop(first.lat, first.lng, first.time, last.time, last.battery)
        return result
    }

    /** Evenly picks at most [max] items (keeps the first and the last). */
    fun <T> sample(list: List<T>, max: Int): List<T> {
        if (list.size <= max || max < 2) return list
        return (0 until max).map { i -> list[(i.toLong() * (list.size - 1) / (max - 1)).toInt()] }
    }
}
