package com.example.kidsafe.core

/**
 * Tiny DNS / IPv4 / UDP helpers used by the child's web filter.
 *
 * The filter is a "DNS-only" VPN: only website-name lookups reach it. These functions read one
 * lookup packet, build the "this site does not exist" answer, spot the family DNS's "blocked"
 * answer (0.0.0.0) and wrap an answer back into an IP packet for the app that asked.
 * No Android classes here, so the byte-level logic can be tested on any computer.
 */
object Dns {

    /** One DNS question read from a packet the phone sent into the tunnel. */
    class Query(
        val clientPort: Int,
        val dns: ByteArray,
        val domain: String,
        val questionEnd: Int,
    )

    /** Largest answer we can send back in one packet without fragmenting. */
    const val MAX_REPLY_BYTES = 1472

    fun u16(b: ByteArray, i: Int): Int =
        ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)

    /** Reads an IPv4 + UDP packet addressed to port 53. Returns null if it is anything else. */
    fun parseQuery(p: ByteArray): Query? {
        if (p.size < 28) return null
        if (((p[0].toInt() shr 4) and 0xF) != 4) return null // IPv4 only
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (p[9].toInt() != 17) return null                   // UDP only
        if (p.size < ihl + 8) return null
        val srcPort = u16(p, ihl)
        if (u16(p, ihl + 2) != 53) return null                // DNS only
        val payloadLen = minOf(u16(p, ihl + 4) - 8, p.size - ihl - 8)
        if (payloadLen < 12) return null

        val dns = p.copyOfRange(ihl + 8, ihl + 8 + payloadLen)
        val (domain, questionEnd) = parseQuestion(dns) ?: return null
        return Query(srcPort, dns, domain, questionEnd)
    }

    /** Returns (site name, index just after the question) or null. */
    fun parseQuestion(dns: ByteArray): Pair<String, Int>? {
        var i = 12
        val sb = StringBuilder()
        while (true) {
            if (i >= dns.size) return null
            val len = dns[i].toInt() and 0xFF
            if (len == 0) {
                i++
                break
            }
            if ((len and 0xC0) != 0) return null
            if (i + 1 + len > dns.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(dns, i + 1, len, Charsets.US_ASCII))
            i += 1 + len
        }
        val end = i + 4
        if (end > dns.size) return null
        return sb.toString().lowercase() to end
    }

    /** Builds a "this site does not exist" answer from the question. */
    fun nxdomain(dns: ByteArray, questionEnd: Int): ByteArray {
        val r = dns.copyOf(questionEnd)
        r[2] = 0x81.toByte() // response, recursion desired
        r[3] = 0x83.toByte() // recursion available, NXDOMAIN
        for (i in 6..11) r[i] = 0 // no answers / authority / extra records
        return r
    }

    private fun skipName(r: ByteArray, start: Int): Int {
        var i = start
        while (i < r.size) {
            val len = r[i].toInt() and 0xFF
            if (len == 0) return i + 1
            if ((len and 0xC0) == 0xC0) return i + 2
            i += 1 + len
        }
        return -1
    }

    /** The family DNS answers blocked sites with 0.0.0.0 (or ::). */
    fun isSinkholed(r: ByteArray): Boolean {
        if (r.size < 12) return false
        val answers = u16(r, 6)
        if (answers == 0) return false
        var i = skipName(r, 12)
        if (i < 0) return false
        i += 4
        repeat(answers) {
            i = skipName(r, i)
            if (i < 0 || i + 10 > r.size) return false
            val type = u16(r, i)
            val rdLen = u16(r, i + 8)
            val rdata = i + 10
            if (rdata + rdLen > r.size) return false
            if ((type == 1 && rdLen == 4) || (type == 28 && rdLen == 16)) {
                if ((rdata until rdata + rdLen).all { r[it].toInt() == 0 }) return true
            }
            i = rdata + rdLen
        }
        return false
    }

    fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0
        var i = off
        while (i < off + len - 1) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    /** Wraps a DNS answer into an IPv4/UDP packet addressed back to the app that asked. */
    fun buildReply(req: ByteArray, clientPort: Int, dns: ByteArray): ByteArray {
        val total = 20 + 8 + dns.size
        val out = ByteArray(total)
        out[0] = 0x45
        out[2] = (total shr 8).toByte()
        out[3] = total.toByte()
        out[6] = 0x40 // don't fragment
        out[8] = 64   // TTL
        out[9] = 17   // UDP
        System.arraycopy(req, 16, out, 12, 4) // from = the DNS address
        System.arraycopy(req, 12, out, 16, 4) // to   = the app's address
        val ipSum = checksum(out, 0, 20)
        out[10] = (ipSum shr 8).toByte()
        out[11] = ipSum.toByte()

        out[20] = 0
        out[21] = 53
        out[22] = (clientPort shr 8).toByte()
        out[23] = clientPort.toByte()
        val udpLen = 8 + dns.size
        out[24] = (udpLen shr 8).toByte()
        out[25] = udpLen.toByte()
        // UDP checksum 0 = "not used" (allowed for IPv4)
        System.arraycopy(dns, 0, out, 28, dns.size)
        return out
    }
}
