package com.example.kidsafe.ui

import android.text.format.DateUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** "5 minutes ago". A time slightly in the future (clock difference) reads as "0 minutes ago". */
fun agoText(time: Long?): String {
    if (time == null) return "just now"
    val now = System.currentTimeMillis()
    return DateUtils.getRelativeTimeSpanString(minOf(time, now), now, DateUtils.MINUTE_IN_MILLIS).toString()
}

/** "14:05" in the phone's own time zone. */
fun clockText(time: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))

/** "Sat 7 Nov" in the phone's own time zone. */
fun dayText(time: Long): String =
    SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(time))
