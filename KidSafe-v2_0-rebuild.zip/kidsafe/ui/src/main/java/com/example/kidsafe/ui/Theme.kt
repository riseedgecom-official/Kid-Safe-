package com.example.kidsafe.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One "mood" of a banner / pill: its background, its text colour and a stronger accent colour. */
data class ToneColors(val container: Color, val content: Color, val accent: Color)

/** Colours the Material scheme does not have: success / warning / info on top of error. */
data class KsColors(
    val info: ToneColors,
    val success: ToneColors,
    val warning: ToneColors,
    val danger: ToneColors,
    val neutral: ToneColors,
)

private val LightKs = KsColors(
    info = ToneColors(Color(0xFFE4EDFF), Color(0xFF0B2E7A), Color(0xFF165DFF)),
    success = ToneColors(Color(0xFFE3F6E8), Color(0xFF0F5A27), Color(0xFF1E8E3E)),
    warning = ToneColors(Color(0xFFFFF1D6), Color(0xFF7A4A00), Color(0xFFB26A00)),
    danger = ToneColors(Color(0xFFFDE7E4), Color(0xFF8C1D12), Color(0xFFB42318)),
    neutral = ToneColors(Color(0xFFEAF0FA), Color(0xFF33415C), Color(0xFF566175)),
)

private val DarkKs = KsColors(
    info = ToneColors(Color(0xFF1C3B8A), Color(0xFFDCE7FF), Color(0xFF7AA7FF)),
    success = ToneColors(Color(0xFF12391F), Color(0xFFBFEBCB), Color(0xFF5FD08A)),
    warning = ToneColors(Color(0xFF4A3300), Color(0xFFFFE2A8), Color(0xFFFFC24D)),
    danger = ToneColors(Color(0xFF4F1B15), Color(0xFFFFD3CE), Color(0xFFFF8A80)),
    neutral = ToneColors(Color(0xFF1B2640), Color(0xFFC9D3E8), Color(0xFFA9B5CC)),
)

val LocalKsColors = staticCompositionLocalOf { LightKs }

/** Access the extra colours: `Ks.colors.success.accent`. */
object Ks {
    val colors: KsColors
        @Composable get() = LocalKsColors.current
}

private val LightScheme = lightColorScheme(
    primary = Color(0xFF165DFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE4EDFF),
    onPrimaryContainer = Color(0xFF0B2E7A),
    secondary = Color(0xFF55A7FF),
    onSecondary = Color(0xFF09275F),
    background = Color(0xFFF3F6FC),
    onBackground = Color(0xFF172033),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF172033),
    surfaceVariant = Color(0xFFEAF0FA),
    onSurfaceVariant = Color(0xFF566175),
    outline = Color(0xFFD3DCEC),
    error = Color(0xFFB42318),
    onError = Color.White,
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF7AA7FF),
    onPrimary = Color(0xFF08183F),
    primaryContainer = Color(0xFF1C3B8A),
    onPrimaryContainer = Color(0xFFDCE7FF),
    secondary = Color(0xFF8CC0FF),
    onSecondary = Color(0xFF09275F),
    background = Color(0xFF0B1220),
    onBackground = Color(0xFFE6ECF8),
    surface = Color(0xFF121A2B),
    onSurface = Color(0xFFE6ECF8),
    surfaceVariant = Color(0xFF1B2640),
    onSurfaceVariant = Color(0xFFA9B5CC),
    outline = Color(0xFF2C3957),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF3B0A06),
)

private val KsShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

private val KsTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 32.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 16.sp),
)

/** The KidSafe look, used by both apps. Follows the phone's light / dark setting. */
@Composable
fun KsTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalKsColors provides (if (darkTheme) DarkKs else LightKs)) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkScheme else LightScheme,
            typography = KsTypography,
            shapes = KsShapes,
            content = content,
        )
    }
}
